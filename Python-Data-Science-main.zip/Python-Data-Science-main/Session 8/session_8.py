import sys
sys.stdout.reconfigure(encoding='utf-8')

# Task 1: for loop to print 5 favorite food delivery apps, one per line
apps = ["Zomato", "Swiggy", "Blinkit", "Zepto", "EatSure"]
for app in apps:
    print(app)


# Task 2: while loop to find first day crossing 10,000 steps
step_counts = [6500, 8200, 9500, 11200, 7800, 10500, 12000]
days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

i = 0
while i < len(step_counts):
    if step_counts[i] > 10000:
        print(f"First day crossing 10,000 steps: {days[i]} ({step_counts[i]} steps)")
        break
    i += 1


# Task 3: Function to print IPL teams longer than 6 chars using continue
def print_long_team_names(teams):
    for team in teams:
        if len(team) <= 6:
            continue
        print(team)

ipl_teams = ["CSK", "MI", "RCB", "KKR", "Gujarat Titans", "Rajasthan Royals", "Delhi Capitals"]
print_long_team_names(ipl_teams)


# Task 4: for loop with enumerate for Spotify song durations (starting from 1)
song_durations = [210, 185, 240, 195, 225]
for index, duration in enumerate(song_durations, start=1):
    print(f"Song {index}: {duration} seconds")


# Task 5: Flipkart cart calculator using both break and continue
cart_prices = [450, 0, 850, 0, 900, 350, 600]
running_total = 0

for price in cart_prices:
    if price == 0:
        continue  # skip out of stock items
    running_total += price
    if running_total > 2000:
        break  # stop adding if total crosses 2000

print(f"Final total: ₹{running_total}")
