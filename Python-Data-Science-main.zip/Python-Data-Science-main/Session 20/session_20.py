from abc import ABC, abstractmethod

# Task 1: Playlist class with private attribute _songs and add_song() method
class Playlist:
    def __init__(self):
        self._songs = []

    def add_song(self, song):
        self._songs.append(song)

    def get_songs(self):
        return self._songs

playlist = Playlist()
playlist.add_song("Kesariya")
playlist.add_song("Chaleya")
playlist.add_song("Apna Bana Le")
print("Playlist songs:", playlist.get_songs())


# Task 2: Product class with private _price, get_price(), and set_price()
class Product:
    def __init__(self, name, price):
        self.name = name
        self._price = float(price)

    def get_price(self):
        return self._price

    def set_price(self, new_price):
        if new_price >= 0:
            self._price = float(new_price)
        else:
            print("Error: Price cannot be negative.")

product = Product("Boat Rockerz Headphones", 1499.0)
print(f"Product: {product.name} | Initial Price: Rs.{product.get_price()}")
product.set_price(1299.0)
print(f"Product: {product.name} | Updated Price: Rs.{product.get_price()}")


# Task 3: Movie class with private _rating and validated getter/setter (0 to 10)
class Movie:
    def __init__(self, title, rating=0.0):
        self.title = title
        self._rating = 0.0
        self.set_rating(rating)

    def get_rating(self):
        return self._rating

    def set_rating(self, rating):
        if 0.0 <= rating <= 10.0:
            self._rating = float(rating)
        else:
            print(f"Error: Rating {rating} is invalid! Must be between 0 and 10.")

movie = Movie("Inception", 8.8)
print(f"Movie: {movie.title} | Rating: {movie.get_rating()}")
movie.set_rating(12.5)  # Triggers error message
movie.set_rating(9.2)   # Valid update
print(f"Movie: {movie.title} | New Rating: {movie.get_rating()}")


# Task 4: Abstract class PaymentMethod and subclasses Paytm & PhonePe
class PaymentMethod(ABC):
    @abstractmethod
    def pay(self, amount):
        pass

class Paytm(PaymentMethod):
    def pay(self, amount):
        print(f"Paid Rs.{amount:.2f} successfully via Paytm Wallet.")

class PhonePe(PaymentMethod):
    def pay(self, amount):
        print(f"Paid Rs.{amount:.2f} successfully via PhonePe UPI.")

paytm_user = Paytm()
phonepe_user = PhonePe()

paytm_user.pay(450.0)
phonepe_user.pay(850.0)
