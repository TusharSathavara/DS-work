# Task 1: Create a list called playlist_ids with 5 song IDs and print
playlist_ids = [101, 102, 103, 104, 105]
print("Initial playlist:", playlist_ids)


# Task 2: Add two more song IDs using append() and extend(), then print
playlist_ids.append(106)       # append for a single ID
playlist_ids.extend([107])     # extend for adding an iterable
print("Updated playlist:", playlist_ids)


# Task 3: Remove last played song using pop(), display removed ID and remaining playlist
removed_id = playlist_ids.pop()
print("Removed song ID:", removed_id)
print("Remaining playlist:", playlist_ids)


# Task 4: Create tuple insta_filters, try to modify first element, observe TypeError
insta_filters = ("Clarendon", "Gingham", "Juno", "Lark")
try:
    insta_filters[0] = "Valencia"
except TypeError as e:
    # Error: 'tuple' object does not support item assignment
    print("Observed Error:", e)


# Task 5: Scenario - List vs Tuple
# Explanation in comment:
# Recent Zomato orders change dynamically as users place or cancel orders, requiring a mutable List.
# Fixed IPL team names remain constant throughout the season, requiring an immutable Tuple.
print("Recent Zomato Orders: Use List (mutable, changes dynamically)")
print("Fixed IPL Team Names: Use Tuple (immutable, fixed collection)")
