# Custom module: playlist_utils.py
def add_song(playlist, song):
    playlist.append(song)
    return playlist
