import math
import os
from datetime import datetime
import playlist_utils
import requests

# Task 1: Calculate square root of 225 using math module
sqrt_result = math.sqrt(225)
print("Square root of 225:", sqrt_result)


# Task 2: Create 'MyDownloads' folder using os module and print absolute path
folder_name = "MyDownloads"
os.makedirs(folder_name, exist_ok=True)
abs_path = os.path.abspath(folder_name)
print("Absolute path of new folder:", abs_path)


# Task 3: Current date and time formatted as 'DD-MM-YYYY HH:MM:SS'
current_time = datetime.now()
formatted_time = current_time.strftime("%d-%m-%Y %H:%M:%S")
print("Current timestamp:", formatted_time)


# Task 4: Import custom module playlist_utils to add 3 songs and print playlist
playlist = []
playlist_utils.add_song(playlist, "Kesariya")
playlist_utils.add_song(playlist, "Chaleya")
playlist_utils.add_song(playlist, "Apna Bana Le")
print("Final playlist:", playlist)


# Task 5: Import requests and print installed version
print("Requests version installed:", requests.__version__)
