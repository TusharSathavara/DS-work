import sys
sys.stdout.reconfigure(encoding='utf-8')

# Task 1: get_song_duration_per_minute with try, except, finally
def get_song_duration_per_minute(total_duration, num_songs):
    try:
        avg_duration = total_duration / num_songs
        return avg_duration
    except ZeroDivisionError:
        print("Error: Playlist has zero songs.")
        return 0
    finally:
        print("Playlist calculation attempt finished.")

print("Duration per minute:", get_song_duration_per_minute(60, 15))
print("Duration per minute (0 songs):", get_song_duration_per_minute(60, 0))


# Task 2: Flipkart price-per-item calculator with try-except
def calculate_price_per_item(total_cart_amount, item_count):
    try:
        price_per_item = total_cart_amount / item_count
        print(f"Price per item: ₹{price_per_item:.2f}")
    except ZeroDivisionError:
        print("Oops! Item count cannot be zero in your cart.")

calculate_price_per_item(1500, 3)
calculate_price_per_item(1500, 0)


# Task 3: Custom exception NoOffersApplied for Paytm cashback calculator
class NoOffersApplied(Exception):
    pass

def calculate_paytm_cashback(total_spend, offers_applied):
    try:
        if offers_applied == 0:
            raise NoOffersApplied("No offers applied! Cannot calculate average cashback.")
        avg_cashback = total_spend / offers_applied
        print(f"Average cashback per offer: ₹{avg_cashback:.2f}")
    except NoOffersApplied as e:
        print(f"Paytm Error: {e}")

calculate_paytm_cashback(500, 2)
calculate_paytm_cashback(500, 0)


# Task 4: Refactored calculate_average_rating with try, except, finally
def calculate_average_rating(total_rating, num_reviews):
    try:
        return total_rating / num_reviews
    except ZeroDivisionError:
        print("Error: Number of reviews is zero.")
        return 0
    finally:
        print('Thank you for using the calculator')

print(calculate_average_rating(500, 0))


# Task 5: safe_divide_for_zomato with try, except, else, finally
def safe_divide_for_zomato(bill_amount, num_people):
    try:
        split_amount = bill_amount / num_people
    except ZeroDivisionError:
        print("Custom Error: Bill cannot be split among 0 people!")
    else:
        print(f"Each person pays: ₹{split_amount:.2f}")
    finally:
        print('Split calculation done')

safe_divide_for_zomato(1200, 4)
safe_divide_for_zomato(1200, 0)
