﻿import json
import os
import time
import requests
import schedule

# 10 popular cryptocurrencies on Binance
SYMBOLS = [
    "BTCUSDT",
    "ETHUSDT",
    "BNBUSDT",
    "SOLUSDT",
    "XRPUSDT",
    "ADAUSDT",
    "DOGEUSDT",
    "AVAXUSDT",
    "DOTUSDT",
    "TRXUSDT"
]

BINANCE_24HR_URL = "https://api.binance.com/api/v3/ticker/24hr"
JSON_FILENAME = "crypto_data.json"


# =====================================================================
# TASK 5: Error Handling & Rate Limit Management with Exponential Backoff
# =====================================================================
def fetch_binance_data(symbols, max_retries=3):
    """
    Fetches 24-hour ticker data from Binance API with error handling
    and exponential backoff to handle HTTP 429 rate limits gracefully.
    """
    symbols_param = json.dumps(symbols, separators=(",", ":"))
    params = {"symbols": symbols_param}

    for attempt in range(max_retries):
        try:
            response = requests.get(BINANCE_24HR_URL, params=params, timeout=10)

            # Handle HTTP 429 (Too Many Requests / Rate Limit)
            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 2 ** attempt))
                print(f"[HTTP 429] Rate limit hit. Retrying in {retry_after}s... (Attempt {attempt + 1}/{max_retries})")
                time.sleep(retry_after)
                continue

            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            backoff_delay = 2 ** attempt
            print(f"[Request Error] {e}. Retrying in {backoff_delay}s... (Attempt {attempt + 1}/{max_retries})")
            time.sleep(backoff_delay)

    print("[Error] Failed to fetch data from Binance after maximum retries.")
    return None


# =====================================================================
# TASK 1: Fetch 24-Hour Price & Volume Data and Save to crypto_data.json
# =====================================================================
def fetch_and_save_data():
    print("--- Task 1: Fetching 24h Data & Saving to JSON ---")
    data = fetch_binance_data(SYMBOLS)
    if data:
        with open(JSON_FILENAME, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        print(f"Successfully fetched {len(data)} coins and saved raw JSON to '{JSON_FILENAME}'.\n")
        return data
    else:
        print("Failed to save data.\n")
        return []


# =====================================================================
# TASK 2: Find Most Volatile Coin
# =====================================================================
def find_most_volatile_coin(data):
    """
    Returns the symbol of the coin with the highest percentage price change
    in the last 24 hours.
    """
    if not data:
        return None
    # Volatility is determined by the largest absolute percentage change in 24 hours
    most_volatile = max(data, key=lambda coin: abs(float(coin.get("priceChangePercent", 0))))
    return most_volatile.get("symbol")


# =====================================================================
# TASK 3: Coins Currently Trading Below Average Price
# =====================================================================
def filter_coins_below_average_price():
    print("--- Task 3: Coins Trading Below Average Price ---")
    if not os.path.exists(JSON_FILENAME):
        print(f"File {JSON_FILENAME} not found.")
        return

    with open(JSON_FILENAME, "r", encoding="utf-8") as f:
        data = json.load(f)

    prices = [float(coin["lastPrice"]) for coin in data]
    avg_price = sum(prices) / len(prices)

    print(f"Average Price of all {len(data)} coins: ${avg_price:,.2f}")
    print("Coins currently trading below average price:")

    for coin in data:
        price = float(coin["lastPrice"])
        if price < avg_price:
            print(f"  - {coin['symbol']:<10} : ${price:,.4f}")
    print()


# =====================================================================
# TASK 4: Rank Coins by Total Traded Volume
# =====================================================================
def rank_coins_by_volume(data):
    """
    Sorts all coins by their total traded volume (quoteVolume in USDT)
    in descending order and prints the top 5 coins with their rank and volume.
    """
    print("--- Task 4: Top 5 Coins Ranked by Traded Volume ---")
    # quoteVolume is the total volume in USDT, allowing standardized comparison
    sorted_coins = sorted(data, key=lambda coin: float(coin.get("quoteVolume", 0)), reverse=True)

    print(f"{'Rank':<6} {'Symbol':<12} {'Total Traded Volume (USDT)':<30}")
    print("-" * 50)
    for rank, coin in enumerate(sorted_coins[:5], start=1):
        volume_usdt = float(coin.get("quoteVolume", 0))
        print(f"{rank:<6} {coin['symbol']:<12} ${volume_usdt:>25,.2f}")
    print()


# =====================================================================
# Complete Pipeline & Task 5 Automation
# =====================================================================
def run_pipeline():
    """Executes the complete Binance data fetch and analysis pipeline."""
    print("=" * 60)
    print(f"Binance Crypto Tracker Execution - {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # Task 1
    data = fetch_and_save_data()
    if not data:
        return

    # Task 2
    print("--- Task 2: Most Volatile Coin ---")
    volatile_coin = find_most_volatile_coin(data)
    for coin in data:
        if coin.get("symbol") == volatile_coin:
            pct = float(coin.get("priceChangePercent", 0))
            print(f"Most Volatile Coin: {volatile_coin} (24h Price Change: {pct:+.2f}%)\n")
            break

    # Task 3
    filter_coins_below_average_price()

    # Task 4
    rank_coins_by_volume(data)


def task_5_schedule():
    print("--- Task 5: Hourly Automation Setup ---")
    # Schedule pipeline to run every hour
    schedule.every(1).hours.do(run_pipeline)
    print("Scheduled job added: Runs every 1 hour via schedule library.")
    print("Executing 1 scheduled cycle now for verification:\n")
    schedule.run_all()
    print("Hourly scheduler configured successfully.")
    print("(To run indefinitely in production: while True: schedule.run_pending(); time.sleep(60))\n")


if __name__ == "__main__":
    task_5_schedule()
