import requests
import json
import csv

# Task 1: POST request to https://jsonplaceholder.typicode.com/posts with JSON payload
payload_1 = {
    "title": "Data Science Insights",
    "body": "Learning APIs using Python requests library.",
    "userId": 5
}
resp_1 = requests.post("https://jsonplaceholder.typicode.com/posts", json=payload_1)
print("Task 1 Status Code:", resp_1.status_code)
print("Task 1 Response Data:", resp_1.json())


# Task 2: Prompt user for playlist name and description, POST to mock API, print returned ID
try:
    playlist_name = input("\nEnter playlist name: ").strip() or "Chill Vibes 2024"
    playlist_desc = input("Enter playlist description: ").strip() or "Relaxing beats and acoustic hits."
except (EOFError, KeyboardInterrupt):
    playlist_name = "Chill Vibes 2024"
    playlist_desc = "Relaxing beats and acoustic hits."

playlist_payload = {
    "title": playlist_name,
    "body": playlist_desc,
    "userId": 1
}
resp_2 = requests.post("https://jsonplaceholder.typicode.com/posts", json=playlist_payload)
result_2 = resp_2.json()
print("Task 2 Returned Playlist ID:", result_2.get("id"))


# Task 3: POST request to https://reqres.in/api/users, print user ID and creation timestamp
user_payload = {
    "name": "Chintan",
    "job": "Data Analyst"
}
headers = {"User-Agent": "Mozilla/5.0"}
resp_3 = requests.post("https://reqres.in/api/users", json=user_payload, headers=headers)
data_3 = resp_3.json()
print("\nTask 3 Status Code:", resp_3.status_code)
print("Created User ID:", data_3.get("id"))
print("Creation Timestamp:", data_3.get("createdAt"))


# Task 4: Fetch latest 5 posts and save post titles and userIds to posts.csv
resp_4 = requests.get("https://jsonplaceholder.typicode.com/posts?_limit=5")
posts_5 = resp_4.json()

with open("posts.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["userId", "title"])
    for post in posts_5:
        writer.writerow([post["userId"], post["title"]])
print("\nTask 4: Successfully saved 5 posts to posts.csv")


# Task 5: Save the same API data (5 posts) into a JSON file named posts.json
with open("posts.json", "w", encoding="utf-8") as f:
    json.dump(posts_5, f, indent=2)
print("Task 5: Successfully saved 5 posts to posts.json")
