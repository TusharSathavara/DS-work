# Task 1: Four variables with different data types and type()
age = 22
height = 175.5
name = "Chintan"
has_spotify = True

print(age, type(age))
print(height, type(height))
print(name, type(name))
print(has_spotify, type(has_spotify))


# Task 2: Function total_cart_amount(prices)
def total_cart_amount(prices):
    total = 0.0
    for price in prices:
        total += float(price)
    return total

flipkart_cart = ['199.99', '49', '350.75']
print(total_cart_amount(flipkart_cart))


# Task 3: Cricket score check
score_input = input("Enter score: ")
score = int(score_input)

if score >= 50:
    print('Half-century!')
else:
    print('Keep going!')


# Task 4: Convert is_premium string to boolean
is_premium = 'True'
is_premium = (is_premium.strip().lower() == 'true')
print(is_premium)
print(type(is_premium))
