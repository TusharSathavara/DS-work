# Tasks 1, 2, and 5: Song Class with optional duration and play_preview() method
class Song:
    # Task 5: duration is optional with default value 0
    def __init__(self, title, artist, duration=0):
        self.title = title
        self.artist = artist
        self.duration = duration

    # Task 2: Method to play 30-second preview
    def play_preview(self):
        print(f"Playing 30-second preview of {self.title} by {self.artist}")


# Task 1: Create Song object and print details
fav_song = Song("Kesariya", "Arijit Singh", 268)
print(f"Song Details: Title='{fav_song.title}', Artist='{fav_song.artist}', Duration={fav_song.duration}s")

# Task 2 Call
fav_song.play_preview()

# Task 5 Demonstration: Song object with default duration
song_without_duration = Song("Apna Bana Le", "Arijit Singh")
print(f"Default Duration Song: Title='{song_without_duration.title}', Duration={song_without_duration.duration}s")


# Tasks 3 and 4: FoodOrder Class with constructor and add_item() method
class FoodOrder:
    # Task 3: Constructor initializing restaurant_name, items, and total_price
    def __init__(self, restaurant_name, items, total_price):
        self.restaurant_name = restaurant_name
        self.items = list(items)
        self.total_price = float(total_price)

    # Task 4: Method to add item and update total_price
    def add_item(self, item_name, item_price):
        self.items.append(item_name)
        self.total_price += item_price

    def display_order(self):
        print(f"Restaurant: {self.restaurant_name} | Items: {self.items} | Total: Rs.{self.total_price:.2f}")


# Task 3: Create initial order object and print details
my_order = FoodOrder("Zomato - Pizza Hut", ["Margherita Pizza", "Garlic Bread"], 499.0)
print("\nInitial Order Details:")
my_order.display_order()

# Task 4: Add two items to order and print updated total
my_order.add_item("Pepsi Can", 60.0)
my_order.add_item("Choco Lava Cake", 110.0)

print("\nUpdated Order Details after adding 2 items:")
my_order.display_order()
