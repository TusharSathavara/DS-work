import sys
sys.stdout.reconfigure(encoding='utf-8')

# Task 1: Dictionary insta_followers with 5 influencers
insta_followers = {
    "virat.kohli": 270000000,
    "shraddhakapoor": 93000000,
    "aliaabhatt": 85000000,
    "ranveersingh": 47000000,
    "deepikapadukone": 79000000
}
print("Initial insta_followers:", insta_followers)


# Task 2: Add new influencer, update existing, delete one, and print
insta_followers["rohitsharma45"] = 40000000    # Add new
insta_followers["virat.kohli"] = 275000000     # Update existing
del insta_followers["ranveersingh"]            # Delete one
print("Updated insta_followers:", insta_followers)


# Task 3: Display Zomato food items costing more than ₹200
food_prices = {
    "Veg Biryani": 180,
    "Paneer Butter Masala": 260,
    "Garlic Naan": 60,
    "Chicken Tikka": 320,
    "Margherita Pizza": 240
}

print("Items costing more than ₹200:")
for item, price in food_prices.items():
    if price > 200:
        print(f"  {item}: ₹{price}")


# Task 4: Set intersection for users on both Flipkart and Myntra
flipkart_users = {"rahul_99", "priya_s", "amit_k", "neha_v", "chintan_d"}
myntra_users = {"sneha_m", "priya_s", "chintan_d", "vikram_r", "karan_j"}

common_users = flipkart_users.intersection(myntra_users)  # or flipkart_users & myntra_users
print("Users on both platforms:", common_users)


# Task 5: Function to return union of artists across two Spotify playlists
def get_unique_artists(spotify_playlist1, spotify_playlist2):
    return spotify_playlist1.union(spotify_playlist2)  # or spotify_playlist1 | spotify_playlist2

playlist_a = {"Arijit Singh", "Shreya Ghoshal", "Diljit Dosanjh"}
playlist_b = {"A.R. Rahman", "Diljit Dosanjh", "Pritam"}
unique_artists = get_unique_artists(playlist_a, playlist_b)
print("All unique artists:", unique_artists)
