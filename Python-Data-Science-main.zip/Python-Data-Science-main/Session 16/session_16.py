# Task 1: iter() and next() to manually print 5 food delivery apps
apps = ["Zomato", "Swiggy", "Domino's", "Blinkit", "Zepto"]
app_iter = iter(apps)

print(next(app_iter))
print(next(app_iter))
print(next(app_iter))
print(next(app_iter))
print(next(app_iter))


# Task 2: Generator function playlist_generator yielding songs one at a time
def playlist_generator(songs):
    for song in songs:
        yield song

my_songs = ["Kesariya", "Apna Bana Le", "Chaleya", "Tum Hi Ho"]
for song in playlist_generator(my_songs):
    print("Now Playing:", song)


# Task 3: enumerate() to print index and name of cart items
cart = ['Pizza', 'Burger', 'Fries', 'Coke']
for index, item in enumerate(cart, start=1):
    print(f"Item #{index}: {item}")


# Task 4: zip() to pair cricket team names with IPL points
teams = ["Mumbai Indians", "Chennai Super Kings", "Gujarat Titans", "Kolkata Knight Riders"]
points = [18, 16, 14, 12]

for team, pt in zip(teams, points):
    print(f"Team: {team}, Points: {pt}")


# Task 5: Generator function order_id_generator starting from 1001
def order_id_generator(start_id=1001):
    current_id = start_id
    while True:
        yield current_id
        current_id += 1

order_gen = order_id_generator()
print("Generated Order ID:", next(order_gen))
print("Generated Order ID:", next(order_gen))
print("Generated Order ID:", next(order_gen))
print("Generated Order ID:", next(order_gen))
