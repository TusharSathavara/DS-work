# Task 1: Check Spotify listening time
listening_time = 135

if listening_time > 120:
    print('You are a true music fan!')
else:
    print('Keep listening!')


# Task 2: Check Zomato order amount for free delivery
order_amount = float(input("Enter your Zomato order amount: "))

if order_amount > 300:
    print('Eligible for free delivery')
else:
    print('Delivery charges apply')


# Task 3: Flipkart cart discount logic
cart_total = 1500

if cart_total > 2000:
    print('You get a 10% discount')
elif cart_total > 1000:
    print('You get a 5% discount')
else:
    print('No discount available')


# Task 4: IPL fantasy team points check using nested if-else
points = int(input("Enter your IPL fantasy team points: "))

if points > 500:
    if points > 800:
        print('Champion')
    else:
        print('Top Performer')
else:
    print('Keep Trying')
