# Task 1: Recursive function to print playlist songs
def print_playlist_songs(songs):
    if not songs:
        return
    print(songs[0])
    print_playlist_songs(songs[1:])

playlist = ["Kesariya", "Apna Bana Le", "Chaleya", "Tum Hi Ho"]
print_playlist_songs(playlist)


# Task 2: Recursive function to count unread messages in nested WhatsApp groups
def count_unread_messages(group):
    total = group.get("count", 0)
    for subgroup in group.get("subgroups", []):
        total += count_unread_messages(subgroup)
    return total

chat_data = {
    "name": "College Community",
    "count": 5,
    "subgroups": [
        {"name": "Study Group", "count": 12, "subgroups": []},
        {
            "name": "Sports Club",
            "count": 3,
            "subgroups": [
                {"name": "Cricket Team", "count": 7, "subgroups": []}
            ]
        }
    ]
}
print("Total unread messages:", count_unread_messages(chat_data))


# Task 3: Variable Scope Analysis
# Explanation:
# - Global variable: `x = 'global'` at module level.
# - Enclosing/Local variable: `x = 'outer'` inside `outer()`.
# - `nonlocal x` inside `inner()` modifies `outer`'s `x` to 'inner'.
# - The global `x` remains unchanged ('global').
# Output when run:
#   Inside outer: inner
#   Outside: global

x = 'global'
def outer():
    x = 'outer'
    def inner():
        nonlocal x
        x = 'inner'
    inner()
    print('Inside outer:', x)

outer()
print('Outside:', x)


# Task 4: Recursive function to format number into short string ('K', 'M')
def format_number_short(n, level=0):
    suffixes = ['', 'K', 'M', 'B']
    if n < 1000 or level >= len(suffixes) - 1:
        if level == 0:
            return str(int(n))
        val = round(n, 1)
        val_str = str(int(val)) if val.is_integer() else str(val)
        return val_str + suffixes[level]
    return format_number_short(n / 1000.0, level + 1)

print("500 ->", format_number_short(500))
print("1500 ->", format_number_short(1500))
print("1200000 ->", format_number_short(1200000))
