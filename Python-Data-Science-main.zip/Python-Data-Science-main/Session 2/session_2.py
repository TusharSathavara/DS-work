# Task 1: Swiggy order variables
item_price = 250
delivery_fee = 30
coupon_discount = 20

print("item_price:", item_price)
print("delivery_fee:", delivery_fee)
print("coupon_discount:", coupon_discount)


# Task 2 & Task 3: Flipkart price check with indentation and comments
"""
Check if product price is above 1000.
If yes, print 'Eligible for free delivery', else print 'Delivery charges apply'.
"""
product_price = 1299

if product_price > 1000:
    print('Eligible for free delivery')
else:
    print('Delivery charges apply')


# Task 4: IPL match variables in snake_case
team_name = "Mumbai Indians"
runs_scored = 198
overs_played = 20.0

print("team_name:", team_name)
print("runs_scored:", runs_scored)
print("overs_played:", overs_played)
