# Python Data Science

## Session 1 - Introduction to Python & Installation

### Tasks Completed

1. Installed Anaconda and launched Jupyter Notebook.
2. Created `insta_intro.ipynb`
   - Printed my name.
   - Printed my favorite app.
3. Printed the message:
   `Welcome to Data Science with Python!`
4. Created `hello_app.py` and ran it successfully from the terminal.

## Technologies Used

- Python
- Anaconda
- Jupyter Notebook
