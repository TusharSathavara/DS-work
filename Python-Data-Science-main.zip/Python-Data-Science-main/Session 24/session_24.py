import csv
import requests

# Task 1, 2, 3, 4: CoinGecko Top 10 Crypto Tracker with Error Handling & CSV Export
url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1"
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
csv_file = "crypto_prices.csv"

try:
    # Task 4: Error handling and status code check
    response = requests.get(url, headers=headers, timeout=10)
    
    if response.status_code != 200:
        print(f"Error: API request failed with status code {response.status_code}. Please try again later.")
    else:
        coins_data = response.json()
        
        # Prepare list for CSV writing
        csv_rows = []
        
        print("=" * 85)
        print(f"{'#':<3} {'Name':<18} {'Price (USD)':<14} {'24h Change %':<16} {'24h High':<14} {'24h Low':<14}")
        print("=" * 85)
        
        for idx, coin in enumerate(coins_data, start=1):
            name = coin.get("name", "N/A")
            price = coin.get("current_price", 0.0)
            change_24h = coin.get("price_change_percentage_24h", 0.0)
            high_24h = coin.get("high_24h", 0.0)
            low_24h = coin.get("low_24h", 0.0)
            
            # Task 1 & Task 2: Print coin details
            print(f"{idx:<3} {name:<18} ${price:<13,.2f} {change_24h:>12.2f}%   ${high_24h:<13,.2f} ${low_24h:<13,.2f}")
            
            # Append data row for CSV
            csv_rows.append({
                "name": name,
                "current_price": price,
                "price_change_percentage_24h": change_24h,
                "high_24h": high_24h,
                "low_24h": low_24h
            })
            
        print("=" * 85)
        
        # Task 3: Save to CSV
        with open(csv_file, "w", newline="", encoding="utf-8") as f:
            fieldnames = ["name", "current_price", "price_change_percentage_24h", "high_24h", "low_24h"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(csv_rows)
            
        print(f"\n[SUCCESS] Successfully saved top 10 cryptocurrencies to '{csv_file}'")

except requests.exceptions.RequestException as e:
    # Task 4: Friendly error message on network failure
    print(f"Network error: Unable to connect to CoinGecko API. ({e})")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
