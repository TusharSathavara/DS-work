import requests
import asyncio
import httpx
from urllib.parse import urlencode

# Task 1: requests.Session() to fetch Flipkart order history page twice without logging in
session = requests.Session()
flipkart_orders_url = "https://www.flipkart.com/account/orders"
headers = {"User-Agent": "Mozilla/5.0"}

resp1_1 = session.get(flipkart_orders_url, headers=headers)
resp1_2 = session.get(flipkart_orders_url, headers=headers)
print("--- Task 1: requests.Session() ---")
print("First Request Status Code :", resp1_1.status_code)
print("Second Request Status Code:", resp1_2.status_code)
print("Cookies preserved in session:", len(session.cookies))


# Task 2: OpenWeatherMap API call for Ahmedabad
print("\n--- Task 2: OpenWeatherMap API ---")
weather_url = "https://api.openweathermap.org/data/2.5/weather"
weather_params = {
    "q": "Ahmedabad",
    "appid": "your_api_key_here",  # Replace with your actual OpenWeatherMap API key
    "units": "metric"
}
weather_resp = requests.get(weather_url, params=weather_params)
print("Weather API Status Code:", weather_resp.status_code)
if weather_resp.status_code == 200:
    temp = weather_resp.json()["main"]["temp"]
    print(f"Current Temperature in Ahmedabad: {temp}°C")
else:
    print("Response message:", weather_resp.json().get("message", "API Key required for live weather"))


# Task 3: Async data fetch using asyncio and httpx.gather()
print("\n--- Task 3: Async Data Fetch (Spotify & BookMyShow Simulation) ---")
async def fetch_spotify_trending(client):
    resp = await client.get("https://jsonplaceholder.typicode.com/posts?_limit=3")
    return [f"Song: {item['title'][:20]}" for item in resp.json()]

async def fetch_bookmyshow_movies(client):
    resp = await client.get("https://jsonplaceholder.typicode.com/posts?_start=10&_limit=3")
    return [f"Movie: {item['title'][:20]}" for item in resp.json()]

async def main_async():
    async with httpx.AsyncClient() as client:
        songs, movies = await asyncio.gather(
            fetch_spotify_trending(client),
            fetch_bookmyshow_movies(client)
        )
        print("Async Spotify Songs   :", songs)
        print("Async BookMyShow Movies:", movies)

asyncio.run(main_async())


# Task 4: Function get_user_profile() with Bearer token authentication
print("\n--- Task 4: Bearer Token Authentication ---")
def get_user_profile():
    bearer_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.fake_token_xyz123"
    auth_headers = {
        "Authorization": f"Bearer {bearer_token}"
    }
    user_url = "https://jsonplaceholder.typicode.com/users/1"
    response = requests.get(user_url, headers=auth_headers)
    if response.status_code == 200:
        name = response.json().get("name")
        print("User Profile Name:", name)
    else:
        print("Request failed with status code:", response.status_code)

get_user_profile()


# Task 5: Step 1 of OAuth 2.0 flow (generating authorization redirect URL for Spotify)
print("\n--- Task 5: OAuth 2.0 Authorization URL Generator ---")
# Explanation:
# In OAuth 2.0, the first step is redirecting the user's browser to the service provider's
# authorization endpoint with query parameters (client_id, response_type='code', redirect_uri, scope).
# The user logs in and consents, after which the service redirects back with an authorization code.

def generate_spotify_oauth_url(client_id, redirect_uri, scopes):
    base_url = "https://accounts.spotify.com/authorize"
    params = {
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "scope": " ".join(scopes),
        "state": "secure_random_state_98765"
    }
    return f"{base_url}?{urlencode(params)}"

spotify_oauth_url = generate_spotify_oauth_url(
    client_id="sample_spotify_client_id_12345",
    redirect_uri="https://myapp.com/callback",
    scopes=["user-read-private", "user-read-email", "playlist-modify-public"]
)
print("Generated Spotify OAuth 2.0 URL:\n", spotify_oauth_url)
