import sys
sys.stdout.reconfigure(encoding='utf-8')

# Task 1: Convert to lowercase, replace dash with a space, and print
text = 'Flipkart-Sale2024'
result_1 = text.lower().replace('-', ' ')
print(result_1)


# Task 2: Remove extra spaces, uppercase, and replace dash with colon
product_name = '  OnePlus Nord-CE 3 '
result_2 = product_name.strip().upper().replace('-', ':')
print(result_2)


# Task 3: Function to split product code by dash
def split_product_code(product_code):
    return product_code.split('-')

print(split_product_code('ZOMATO-FOOD-2024'))


# Task 4: Extract 'Premium' using string slicing
promo_text = 'Spotify_Premium_Offer'
extracted_word = promo_text[8:15]
print(extracted_word)


# Task 5: Format and print message using string formatting
product = 'Myntra Shirt'
price = 799.5
print(f"Deal: {product} is available at ₹{price:.2f} only!")
