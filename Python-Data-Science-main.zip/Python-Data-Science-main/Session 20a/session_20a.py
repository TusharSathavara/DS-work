import requests

# Task 1: Fetch posts from JSONPlaceholder, print status code and first post title
url_posts = "https://jsonplaceholder.typicode.com/posts"
resp_posts = requests.get(url_posts)
print("Task 1 Status Code:", resp_posts.status_code)

posts = resp_posts.json()
if posts:
    print("First Post Title:", posts[0]["title"])


# Task 2: POST request with title, body, userId, print status code and response JSON
new_post = {
    "title": "My First Post",
    "body": "Hello from Python!",
    "userId": 101
}

resp_post = requests.post(url_posts, json=new_post)
print("\nTask 2 Status Code:", resp_post.status_code)
print("Task 2 Response JSON:", resp_post.json())


# Task 3: Fetch users and print usernames of all users whose email ends with '.org'
url_users = "https://jsonplaceholder.typicode.com/users"
resp_users = requests.get(url_users)
users = resp_users.json()

org_users = [user["username"] for user in users if user["email"].lower().endswith(".org")]
print("\nTask 3 Users with .org email:")
for username in org_users:
    print("-", username)


# Task 4: Fetch movies from OMDB API with query parameters (apikey='demo', s='Avengers')
omdb_url = "http://www.omdbapi.com/"
query_params = {
    "apikey": "demo",
    "s": "Avengers"
}

resp_movies = requests.get(omdb_url, params=query_params)
movie_data = resp_movies.json()

print("\nTask 4 OMDB Response Status Code:", resp_movies.status_code)
total_results = movie_data.get("totalResults", movie_data.get("Error", "N/A"))
print("Total results found:", total_results)
