# Session 1 - Task 4
# Python script executed via terminal
print('Hello from .py file!')
