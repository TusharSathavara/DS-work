import sys
sys.stdout.reconfigure(encoding='utf-8')

# Task 1: Function to calculate final price after discount rate
def calculate_final_price(price, discount_rate):
    # discount_rate e.g. 0.10 or 10%
    discount_amount = price * (discount_rate / 100 if discount_rate > 1 else discount_rate)
    return price - discount_amount

print("Final price (1000 with 15% discount):", calculate_final_price(1000, 15))


# Task 2: Function get_delivery_charge with default city='Ahmedabad'
def get_delivery_charge(amount, city='Ahmedabad'):
    if city.lower() == 'ahmedabad':
        return 0
    else:
        return 50

print("Delivery charge in Ahmedabad:", get_delivery_charge(500))
print("Delivery charge in Mumbai:", get_delivery_charge(500, city='Mumbai'))


# Task 3: Function format_price with default currency='INR'
def format_price(price, currency='INR'):
    if currency == 'INR':
        return f"₹{price}"
    elif currency == 'USD':
        return f"${price}"
    else:
        return f"{currency} {price}"

print(format_price(500))
print(format_price(500, currency='USD'))


# Task 4: Function apply_coupon with default coupon_code=None
def apply_coupon(price, coupon_code=None):
    if coupon_code == 'ZOMATO10':
        return price * 0.90
    else:
        return price

print("Price with ZOMATO10 coupon:", apply_coupon(400, 'ZOMATO10'))
print("Price without coupon:", apply_coupon(400))
