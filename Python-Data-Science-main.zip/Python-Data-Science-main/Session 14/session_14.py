import csv
import json
from pathlib import Path

# Task 1: Create playlist.txt and write 5 song names
with open("playlist.txt", "w", encoding="utf-8") as f:
    songs = ["Kesariya", "Apna Bana Le", "Chaleya", "Tum Hi Ho", "Raataan Lambiyan"]
    for song in songs:
        f.write(song + "\n")
print("playlist.txt created successfully.")


# Task 2: Read playlist.txt and display each song in uppercase
with open("playlist.txt", "r", encoding="utf-8") as f:
    for line in f:
        print(line.strip().upper())


# Task 3: Create and read IPL match scores CSV, print winner of each match
ipl_csv_file = "ipl_matches.csv"
with open(ipl_csv_file, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["match_id", "team1", "team2", "winner"])
    writer.writerow([1, "CSK", "RCB", "CSK"])
    writer.writerow([2, "MI", "KKR", "MI"])
    writer.writerow([3, "GT", "RR", "GT"])

with open(ipl_csv_file, "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(f"Match {row['match_id']}: Winner is {row['winner']}")


# Task 4: Create movies.json with 3 movies, load using json module, print title and rating
movies_data = [
    {"title": "Inception", "year": 2010, "rating": 8.8},
    {"title": "Interstellar", "year": 2014, "rating": 8.7},
    {"title": "The Dark Knight", "year": 2008, "rating": 9.0}
]

with open("movies.json", "w", encoding="utf-8") as f:
    json.dump(movies_data, f, indent=2)

with open("movies.json", "r", encoding="utf-8") as f:
    loaded_movies = json.load(f)
    for movie in loaded_movies:
        print(f"Title: {movie['title']}, Rating: {movie['rating']}")


# Task 5: Use pathlib to check if 'my_fav_apps.json' exists, if not, write top 3 mobile apps
file_path = Path("my_fav_apps.json")

if not file_path.exists():
    top_apps = [
        {"name": "Instagram", "category": "Social Media"},
        {"name": "Zomato", "category": "Food Delivery"},
        {"name": "Paytm", "category": "Payments"}
    ]
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(top_apps, f, indent=2)
    print("Created 'my_fav_apps.json' with top 3 apps.")
else:
    print("'my_fav_apps.json' already exists.")
