﻿import sys
# Set UTF-8 encoding for standard output
sys.stdout.reconfigure(encoding='utf-8')

# =====================================================================
# TASK 1: Product Class with 10% Discount
# =====================================================================
print("--- Task 1: Product Class ---")

class Product:
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def get_discounted_price(self):
        """Returns price after applying a 10% discount."""
        return self.price * 0.90

product1 = Product("Cotton T-Shirt", 1000.0)
print(f"Product: {product1.name}")
print(f"Original Price: Rs. {product1.price:.2f}")
print(f"Discounted Price (10% off): Rs. {product1.get_discounted_price():.2f}\n")


# =====================================================================
# TASK 2: Electronics Subclass with Overridden 20% Discount
# =====================================================================
print("--- Task 2: Electronics Subclass (Method Overriding) ---")

class Electronics(Product):
    def get_discounted_price(self):
        """Overrides parent method to apply a 20% discount instead of 10%."""
        return self.price * 0.80

gadget = Electronics("Wireless Headphones", 2500.0)
print(f"Electronics Item: {gadget.name}")
print(f"Original Price: Rs. {gadget.price:.2f}")
print(f"Discounted Price (20% off): Rs. {gadget.get_discounted_price():.2f}\n")


# =====================================================================
# TASK 3: Polymorphism with show_final_price() Function
# =====================================================================
print("--- Task 3: Demonstrating Polymorphism ---")

def show_final_price(item):
    """
    Polymorphic function that accepts any Product or Electronics object
    and prints its name and discounted price.
    """
    discounted_price = item.get_discounted_price()
    print(f"Item: {item.name:<22} | Final Price: Rs. {discounted_price:.2f}")

item_general = Product("Backpack", 1500.0)
item_electronics = Electronics("Smart Watch", 4000.0)

print("Calling show_final_price() with different object types:")
show_final_price(item_general)
show_final_price(item_electronics)
print()


# =====================================================================
# TASK 4: Movie Ticket & PremiumTicket with super()
# =====================================================================
print("--- Task 4: Ticket & PremiumTicket with super() ---")

class Ticket:
    def __init__(self, movie_name, base_price):
        self.movie_name = movie_name
        self.base_price = base_price

    def get_final_price(self):
        """Returns the base price of the ticket."""
        return self.base_price

class PremiumTicket(Ticket):
    def get_final_price(self):
        """
        Overrides parent method using super() to add a 50 rupee convenience fee.
        """
        base = super().get_final_price()
        convenience_fee = 50.0
        return base + convenience_fee

# Demonstration
regular_ticket = Ticket("Interstellar", 250.0)
vip_ticket = PremiumTicket("Interstellar (IMAX)", 450.0)

print(f"Movie: {regular_ticket.movie_name}")
print(f"Regular Ticket Final Price: Rs. {regular_ticket.get_final_price():.2f}")

print(f"\nMovie: {vip_ticket.movie_name}")
print(f"Premium Ticket Final Price: Rs. {vip_ticket.get_final_price():.2f} (Includes Rs. 50 convenience fee)")
