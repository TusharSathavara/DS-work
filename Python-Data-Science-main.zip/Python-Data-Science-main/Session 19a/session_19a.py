import requests
import json

# Task 1: GET request to https://jsonplaceholder.typicode.com/posts, print titles of first 5 posts
response = requests.get("https://jsonplaceholder.typicode.com/posts")
posts = response.json()

print("--- First 5 Post Titles ---")
for post in posts[:5]:
    print(f"ID {post['id']}: {post['title']}")


# Task 2: Zomato-style restaurant dictionary converted to JSON string using json.dumps()
restaurant = {
    "name": "Punjab Grill",
    "location": "Vastrapur, Ahmedabad",
    "cuisines": ["North Indian", "Mughlai", "Biryani"],
    "ratings": 4.6
}

restaurant_json_str = json.dumps(restaurant, indent=2)
print("\n--- Zomato Restaurant JSON String ---")
print(restaurant_json_str)


# Task 3: POST request with payload (title, userId, body), print status code and response
new_post = {
    "title": "Top Hits Playlist",
    "userId": 1,
    "body": "Curated collection of top romantic and dance hits."
}

post_response = requests.post("https://jsonplaceholder.typicode.com/posts", json=new_post)
print("\n--- POST Request Result ---")
print("Status Code:", post_response.status_code)
print("Response JSON:", post_response.json())


# Task 4: GET request with query param userId=2, print IDs of returned posts
user2_response = requests.get("https://jsonplaceholder.typicode.com/posts", params={"userId": 2})
user2_posts = user2_response.json()
user2_ids = [p["id"] for p in user2_posts]
print("\n--- Posts for userId=2 ---")
print("Returned Post IDs:", user2_ids)


# Task 5: GET request with custom HTTP headers (e.g., Authorization)
custom_headers = {
    "Authorization": "Bearer sample_token_12345",
    "Custom-Header": "DataScienceApp/1.0"
}

header_response = requests.get("https://jsonplaceholder.typicode.com/posts/1", headers=custom_headers)
print("\n--- Custom Headers Request Result ---")
print("Status Code with Custom Headers:", header_response.status_code)
