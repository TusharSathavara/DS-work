from functools import reduce

# Task 1: Lambda function with map() to lowercase song titles
songs = ['Shape Of You', 'Blinding Lights', 'Levitating', 'Senorita']
lowercase_songs = list(map(lambda s: s.lower(), songs))
print("Lowercased songs:", lowercase_songs)


# Task 2: filter() with lambda for ratings above 4.0
ratings = [4.2, 3.8, 4.5, 2.9, 3.5]
top_ratings = list(filter(lambda r: r > 4.0, ratings))
print("Ratings above 4.0:", top_ratings)


# Task 3: reduce() to calculate total cart price
cart_items = [499, 1299, 299, 799]
total_cart_price = reduce(lambda a, b: a + b, cart_items)
print("Total cart price:", total_cart_price)


# Task 4: format_followers function and map()
def format_followers(n):
    if n >= 1000000:
        return f"{n / 1000000:.1f}M".replace(".0M", "M")
    elif n >= 1000:
        return f"{n / 1000:.1f}K".replace(".0K", "K")
    else:
        return str(n)

follower_counts = [950, 1500, 25000, 1200000]
formatted_counts = list(map(format_followers, follower_counts))
print("Formatted followers:", formatted_counts)


# Task 5: Lambda function that filters out odd numbers (keeps only evens)
# Or filters odd numbers: filter(lambda score: score % 2 != 0, scores)
ipl_scores = [101, 98, 120, 77, 88]
odd_scores = list(filter(lambda score: score % 2 != 0, ipl_scores))
print("Odd IPL scores:", odd_scores)
