import os
import requests
from datetime import datetime

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

# ==============================================================================
# Task 1: OpenWeatherMap API - Temperature & Weather Description
# ==============================================================================
print("--- Task 1: OpenWeatherMap API ---")
api_key = "your_openweathermap_api_key_here"  # Replace with actual OpenWeatherMap API key
city = "Ahmedabad"
weather_url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"

try:
    w_resp = requests.get(weather_url, headers=headers, timeout=10)
    if w_resp.status_code == 200:
        w_data = w_resp.json()
        temp = w_data["main"]["temp"]
        desc = w_data["weather"][0]["description"]
        print(f"City        : {city}")
        print(f"Temperature : {temp}°C")
        print(f"Condition   : {desc.capitalize()}")
    else:
        print(f"OpenWeatherMap API returned status {w_resp.status_code}: {w_resp.json().get('message', 'API key needed')}")
except Exception as e:
    print(f"Error fetching weather: {e}")


# ==============================================================================
# Task 2: CoinGecko API - Bitcoin and Ethereum Prices with Timestamp
# ==============================================================================
print("\n--- Task 2: Live Crypto Prices (CoinGecko API) ---")
crypto_url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd,inr"

try:
    c_resp = requests.get(crypto_url, headers=headers, timeout=10)
    if c_resp.status_code == 200:
        crypto_data = c_resp.json()
        now_str = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
        print(f"Timestamp : {now_str}")
        print(f"Bitcoin   : ${crypto_data['bitcoin']['usd']:,} (Rs.{crypto_data['bitcoin']['inr']:,})")
        print(f"Ethereum  : ${crypto_data['ethereum']['usd']:,} (Rs.{crypto_data['ethereum']['inr']:,})")
    else:
        print(f"CoinGecko API status: {c_resp.status_code}")
except Exception as e:
    print(f"Error fetching crypto prices: {e}")


# ==============================================================================
# Task 3: NASA APOD API - Image Title, Explanation & Local Download
# ==============================================================================
print("\n--- Task 3: NASA Astronomy Picture of the Day (APOD) ---")
nasa_url = "https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY"

try:
    n_resp = requests.get(nasa_url, headers=headers, timeout=10)
    if n_resp.status_code == 200:
        apod_data = n_resp.json()
        print(f"Title       : {apod_data.get('title')}")
        print(f"Explanation : {apod_data.get('explanation')[:150]}...")
        
        # Download and save image locally
        img_url = apod_data.get("url")
        if img_url and img_url.startswith("http"):
            img_resp = requests.get(img_url, headers=headers, timeout=15)
            if img_resp.status_code == 200:
                filename = "nasa_apod_today.jpg"
                with open(filename, "wb") as f:
                    f.write(img_resp.content)
                print(f"[SUCCESS] NASA image saved locally as '{filename}' ({len(img_resp.content):,} bytes)")
    else:
        print(f"NASA API status: {n_resp.status_code}")
except Exception as e:
    print(f"Error fetching NASA APOD: {e}")


# ==============================================================================
# Task 4: COVID-19 Case Numbers for India (Table Format)
# ==============================================================================
print("\n--- Task 4: India COVID-19 Statistics ---")
covid_url = "https://disease.sh/v3/covid-19/countries/India"

try:
    cov_resp = requests.get(covid_url, headers=headers, timeout=10)
    if cov_resp.status_code == 200:
        cov_data = cov_resp.json()
        total_cases = cov_data.get("cases", 0)
        total_recovered = cov_data.get("recovered", 0)
        total_deaths = cov_data.get("deaths", 0)
        
        # Format in clean table
        print("+----------------------+----------------------+")
        print("| Metric               | Count                |")
        print("+----------------------+----------------------+")
        print(f"| Total Cases          | {total_cases:<20,}|")
        print(f"| Total Recovered      | {total_recovered:<20,}|")
        print(f"| Total Deaths         | {total_deaths:<20,}|")
        print("+----------------------+----------------------+")
    else:
        print(f"COVID API status: {cov_resp.status_code}")
except Exception as e:
    print(f"Error fetching COVID stats: {e}")


# ==============================================================================
# Task 5: Combine Two APIs (Weather in Mumbai + Bitcoin Price)
# ==============================================================================
print("\n--- Task 5: Combined Multi-API Dashboard ---")

# API 1: Weather in Mumbai
mumbai_temp = "N/A (API Key required)"
try:
    m_url = f"https://api.openweathermap.org/data/2.5/weather?q=Mumbai&appid={api_key}&units=metric"
    m_resp = requests.get(m_url, headers=headers, timeout=10)
    if m_resp.status_code == 200:
        mumbai_temp = f"{m_resp.json()['main']['temp']}°C"
    else:
        mumbai_temp = "OpenWeatherMap key required (Status 401)"
except Exception as err:
    mumbai_temp = f"Weather API error: {err}"

# API 2: Bitcoin Price
btc_price = "N/A"
try:
    b_url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=inr"
    b_resp = requests.get(b_url, headers=headers, timeout=10)
    if b_resp.status_code == 200:
        btc_inr = b_resp.json()["bitcoin"]["inr"]
        btc_price = f"Rs. {btc_inr:,}"
    else:
        btc_price = f"CoinGecko status {b_resp.status_code}"
except Exception as err:
    btc_price = f"Crypto API error: {err}"

print(f"1. Mumbai Temperature : {mumbai_temp}")
print(f"2. Current Bitcoin    : {btc_price}")
