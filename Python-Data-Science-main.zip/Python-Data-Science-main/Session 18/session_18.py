import re

# Task 1: Extract valid phone numbers in '+91-XXXXXXXXXX' format using re.findall()
text1 = "Customer contacts: +91-9876543210, office: +91-9123456789, invalid: 9876543210, +91-12345"
phone_numbers = re.findall(r"\+91-\d{10}", text1)
print("Extracted phone numbers:", phone_numbers)


# Task 2: Function using re.search() to check for valid date 'DD/MM/YYYY'
def contains_valid_date(text):
    match = re.search(r"\b\d{2}/\d{2}/\d{4}\b", text)
    return match is not None

print("Date check ('Order on 15/08/2024'):", contains_valid_date("Order on 15/08/2024"))
print("Date check ('No date provided'):", contains_valid_date("No date provided"))


# Task 3: Extract numeric prices after 'Rs. ' as integers and print their sum
price_text = "Items purchased: Pizza for Rs. 299, Burger for Rs. 150, Coke for Rs. 50, and Combo for Rs. 1500."
price_values = [int(p) for p in re.findall(r"Rs\.\s*(\d+)", price_text)]
print("Extracted prices:", price_values)
print("Sum of prices:", sum(price_values))


# Task 4: Replace all email addresses with '[hidden email]' using re.sub()
email_text = "Contact support at support@zomato.com or query at help123@gmail.co.in for assistance."
hidden_text = re.sub(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", "[hidden email]", email_text)
print("Modified text:", hidden_text)


# Task 5: Extract unique Instagram usernames (@ followed by letters, numbers, underscores, min 3 chars)
comments_file = "instagram_comments.txt"
sample_comments = """Great post @virat_fan!
Amazing photo by @priya123 and @chintan_dev
Loved this reel @foodie_india
Check this out @travel_bug99
Too short tag @ab (ignored)
Tagging @music_lover_2024
Awesome clicks @photographer_pro
Can't wait to visit with @rohit_fan_club
Nice outfit @fashion_queen
Loved it! @tech_geek_9
"""

with open(comments_file, "w", encoding="utf-8") as f:
    f.write(sample_comments)

with open(comments_file, "r", encoding="utf-8") as f:
    content = f.read()

usernames = re.findall(r"@([a-zA-Z0-9_]{3,})", content)
unique_usernames = sorted(list(set(usernames)))
print("Unique Instagram usernames:", unique_usernames)
